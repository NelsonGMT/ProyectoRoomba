# roomba-grid-a — Propuesta A

Robot diferencial tipo Roomba que recorre metas en una cuadrícula de 6×6 celdas de 50 cm.
ESP32 DevKit V1 + PlatformIO, puente H L298N, dos motorreductores con encoder de cuadratura, MPU6050
y una página web servida por la propia ESP32 para marcar inicio, obstáculos y metas, y elegir A\*, BFS, DFS o UCS.

Sin monitor de batería y sin zumbador. El planificador, la misión, la API y la página web son los mismos
de la Propuesta B; cambian los controladores de hardware, la odometría y el control de movimiento.

## Qué hay en la carpeta

```text
roomba-grid-a/
├── platformio.ini            # entornos esp32dev (robot) y native (pruebas en la PC)
├── include/roomba_config.h   # pines, medidas del robot, ganancias y límites
├── include/roomba_settings.h # ajustes que se cambian desde la web y se guardan en NVS
├── src/main.cpp              # arranque y tareas de FreeRTOS
├── lib/
│   ├── L298n/                # PWM 2 kHz en ENA/ENB, sentido con IN1–IN4, freno activo, límite de 6 V
│   ├── QuadEncoder/          # cuadratura ×4 con PCNT (ESP32Encoder) y velocidad por ventana de 50 ms
│   ├── Mpu6050/              # controlador propio: DLPF 44 Hz, ±250 °/s, sesgo b_z con 500 muestras
│   ├── Pose/                 # odometría + giroscopio Z con filtro complementario (β = 0.95)
│   ├── Motion/               # PI de ruedas, avance, giro, frenado
│   ├── Safety/               # atasco (por encoder) y latido del navegador
│   ├── Planner/              # Grid, BFS, DFS, UCS, A*, Held–Karp, 2-opt, primitivas (sin Arduino)
│   ├── Mission/              # máquina de estados y cola de primitivas
│   └── WebApi/               # Wi-Fi, REST y WebSocket
├── data/                     # index.html, app.js, style.css (se suben a LittleFS)
└── test/test_planner/        # 18 pruebas Unity del planificador
```

## Conexiones

| Señal | GPIO | Notas |
| --- | --- | --- |
| ENA (PWM motor izq.) | 25 | Quita el puente ENA del L298N |
| IN1 / IN2 (motor izq.) | 26 / 27 | |
| ENB (PWM motor der.) | 23 | Quita el puente ENB |
| IN3 / IN4 (motor der.) | 16 / 17 | Solo en módulos WROOM |
| Encoder izq. A / B | 34 / 35 | Pull-up de 4.7 kΩ a 3.3 V (estos pines no tienen pull-up interno) |
| Encoder der. A / B | 18 / 19 | Pull-up de 4.7 kΩ a 3.3 V |
| SDA / SCL (MPU6050) | 21 / 22 | I²C a 400 kHz, dirección 0x68 |
| INT (MPU6050) | 33 | Opcional; el firmware no lo usa por ahora |
| Botón paro / inicio | 4 | A GND, INPUT_PULLUP |
| LED de estado | 2 | LED de la placa |

Encoders y MPU6050 se alimentan con **3.3 V** de la ESP32, no con 5 V, para que sus salidas no pasen de 3.3 V.
Une todas las tierras (batería, L298N, buck, ESP32) en un solo punto.

## Paso a paso

Necesitas VS Code con la extensión PlatformIO, o PlatformIO por consola. Todos los comandos se escriben
**dentro de la carpeta `roomba-grid-a`**. En VS Code: menú *Terminal → New Terminal*.

**1. Pruebas del planificador en tu laptop** (no necesita la ESP32):

```bash
pio test -e native
```

Debe terminar con `18 Tests 0 Failures`. En Windows, `native` necesita un compilador `gcc`;
si no lo tienes, córrelo desde WSL (Ubuntu) con `pip install platformio` y el mismo comando.

**2. Compilar el firmware:**

```bash
pio run -e esp32dev
```

**3. Subir el firmware** (ESP32 conectada por USB):

```bash
pio run -e esp32dev -t upload
```

**4. Subir la página web** a la memoria de la ESP32 (una vez, y cada vez que cambies algo en `data/`):

```bash
pio run -e esp32dev -t uploadfs
```

**5. Ver los mensajes de arranque** (deja el robot quieto: el primer segundo calibra el giroscopio):

```bash
pio device monitor
```

Debes ver algo como:

```text
[roomba-grid-a] arrancando
[motores] L298N a 2000 Hz, duty maximo 0.94 (6.0 V en el motor)
[imu] MPU6050 en 0x68 (WHO_AM_I 0x68), b_z = -0.412 dps, sesgo calibrado al arrancar
[web] AP Roomba-UAMM 192.168.4.1
[roomba-grid-a] listo: AP Roomba-UAMM 192.168.4.1
```

Si dice `WHO_AM_I 0x70`, `0x72` o `0x98`, es un clon de la MPU6050 y funciona igual.

**6. Abrir la interfaz:** conecta el teléfono o la laptop a la red Wi-Fi `Roomba-UAMM`
(clave `roomba-grid`, cámbiala en `roomba_config.h`) y abre `http://192.168.4.1`.

## Primer arranque con motores (con las ruedas en el aire)

1. En la web, sección *Pruebas*: PWM izq `0.4`, der `0.4`, 1000 ms → **Probar PWM**. Las dos ruedas deben
   girar hacia adelante. Si una gira al revés, cambia `LEFT_MOTOR_INVERT` o `RIGHT_MOTOR_INVERT`.
2. Mira *Cuentas izq / der* en Telemetría: las dos deben **subir** al avanzar. Si una baja, cambia
   `LEFT_ENC_INVERT` o `RIGHT_ENC_INVERT` (o intercambia A y B). Si se queda en 0, revisa el cable y los pull-up.
3. **Cuentas por vuelta**: marca la rueda, gírala 10 vueltas a mano y divide las cuentas entre 10.
   Ponlo en *Ajustes → Cuentas por vuelta* (por defecto 1496 = 11 × 34 × 4, el ejemplo de la propuesta).
4. **Separación entre ruedas**: mide de centro a centro de las llantas y ponla en *Ajustes* (por defecto 0.20 m,
   un valor provisional). El UMBmark de la propuesta la afina.
5. **Giroscopio**: con el robot quieto pulsa **Calibrar giroscopio** (5 s). Gira el robot a mano a la izquierda:
   θ debe subir. Si baja, pon `IMU_YAW_SIGN = -1.0f`.
6. Robot en el piso, en una celda: marca esa celda como Inicio con la orientación real y pulsa
   **Colocar robot en el inicio marcado**. Prueba `AVANZAR(1)` y `GIRAR(+90°)`.
7. Con eso bien, marca metas, elige algoritmo, **Planear** y **Ejecutar**.

El botón físico (GPIO 4) hace: paro si está en marcha, ejecutar si hay un plan listo, reanudar si está pausado.
La barra espaciadora en la página también manda PARO.

## Qué cambió respecto a la Propuesta B

| Tema | Propuesta B | Propuesta A (este código) |
| --- | --- | --- |
| Puente H | 2× BTS7960, PWM 20 kHz en RPWM/LPWM, EN compartido | L298N: PWM 2 kHz en ENA/ENB, sentido con IN1–IN4. Freno activo = IN1 = IN2 = alto con EN al 100 %; rueda libre = EN en bajo |
| Límite de voltaje | — | Duty máximo 0.94 = 6 V / (8.4 V − 2 V de caída del L298N), fijo porque no se mide la batería |
| Encoder | Un canal, el signo se suponía por el comando | Cuadratura ×4 con PCNT (biblioteca ESP32Encoder). El signo es real, así que cada rueda puede invertir el sentido dentro de una primitiva |
| Velocidad de rueda | Periodo entre pulsos | Diferencia de cuentas en una ventana de 50 ms |
| IMU | BNO055 (rumbo absoluto del sensor) | MPU6050, solo giroscopio Z. Sesgo b_z con 500 muestras en reposo al arrancar (si se movió, usa el último guardado en NVS) y se reajusta despacio con las ruedas quietas |
| Rumbo | El del BNO055 | Filtro complementario de la propuesta: Δθ = β·(ω_z − b_z)·Δt + (1 − β)·Δθ_enc, con β = 0.95 ajustable en la web (`beta_giro`; 0 = solo encoders). Con las ruedas quietas no se integra |
| Giro en sitio | Frenar y corregir si se pasa (hasta 3 veces) | PD continuo en los dos sentidos. Termina con \|eθ\| < 1.5° y \|ω\| < 5 °/s durante 100 ms, como dice la propuesta |
| Corte del avance | < 2 cuentas + frenado aprendido | < 5 mm + frenado aprendido |
| Botón | GPIO 18 | GPIO 4 (el 18 ahora es del encoder derecho) |
| Calibración desde la web | `/api/imu/calibrar` (6 posiciones del BNO055) | `/api/calibrar` con `{"tipo":"imu"}` (también responde en `/api/imu/calibrar`): robot quieto 5 s |
| Wi-Fi | `Roomba-UAMM-B`, `roomba-b.local` | `Roomba-UAMM`, `roomba.local` (los de la propuesta) |
| Batería y zumbador | Quitados | Quitados: GPIO 32 libre, sin paro por bajo voltaje. Vigila tú el voltaje de la 2S (no bajes de ~6.4 V) |

Valores que **tienes que confirmar** con tu hardware: cuentas por vuelta, radio de rueda (32.5 mm),
separación entre ruedas (0.20 m provisional), `PWM_MIN` y `KFF` de las ruedas (se ajustan con la prueba de PWM).

## API (para probar con `curl` desde la laptop conectada al robot)

Todas las rutas POST esperan JSON. Si no llevan datos, manda `{}`.

```bash
curl http://192.168.4.1/api/estado
curl -X POST -H "Content-Type: application/json" -d '{"obstaculos":[[2,2],[2,3]]}' http://192.168.4.1/api/mapa
curl -X POST -H "Content-Type: application/json" -d '{"algoritmo":"astar","inicio":[0,0],"orientacion":"E","metas":[[4,4],[0,5]],"regresar":false}' http://192.168.4.1/api/plan
curl -X POST -H "Content-Type: application/json" -d '{}' http://192.168.4.1/api/ejecutar
curl -X POST -H "Content-Type: application/json" -d '{"tipo":"imu"}' http://192.168.4.1/api/calibrar
curl -X POST http://192.168.4.1/api/paro
```

| Ruta | Uso |
| --- | --- |
| GET /api/estado | Pose, celda, estado, velocidades, cuentas, sesgo y ω del giroscopio |
| GET, POST /api/mapa | Obstáculos `{obstaculos:[[f,c],…]}` (se guardan en NVS) |
| GET, POST /api/plan | `{algoritmo, heuristica?, inicio, orientacion, metas, regresar, obstaculos?}`; el resultado llega por `/ws` o con GET |
| POST /api/ejecutar | `{confirmar?: true}` |
| POST /api/pausa | Pausa al terminar la primitiva en curso, o reanuda |
| POST /api/paro | Freno activo y luego rueda libre |
| POST /api/calibrar | `{tipo:"imu"}`: sesgo del giroscopio con 500 muestras en reposo, se guarda en NVS |
| POST /api/imu/cero | `{celda:[f,c], orientacion:"E"}`: coloca el robot en esa celda y rumbo |
| GET, POST /api/config | Ganancias, velocidades, c_g, β; `{restablecer:true}` vuelve a `roomba_config.h` |
| POST /api/prueba | `{tipo:"avanzar",celdas:1}`, `{tipo:"girar",grados:90}` o `{tipo:"pwm",izq:0.4,der:0.4,ms:1000}` |
| POST /api/wifi | `{modo:"sta",ssid:"…",clave:"…"}` o `{modo:"ap"}`; reinicia. En estación: `roomba.local` |
| WS /ws | Telemetría cada 100 ms, plan, avisos. El navegador manda `{"tipo":"latido"}` cada segundo |

## Qué está probado y qué no

- **Planificador**: las 18 pruebas pasan (compiladas con g++ y Unity; es el mismo código de la Propuesta B).
- **Firmware**: no se pudo compilar para ESP32 donde se escribió (el registro de PlatformIO está bloqueado en
  esa red). Todos los archivos se revisaron con g++ contra cabeceras de prueba de Arduino, ArduinoJson 7.2 real
  y la interfaz real de ESP32Encoder 0.11.8, sin errores ni avisos. **El primer paso es correr
  `pio run -e esp32dev`** y, si sale algún error, mandarlo tal cual.
- **En el robot real**: nada aún. Las ganancias de `roomba_config.h` son un punto de partida; se ajustan desde la web.
